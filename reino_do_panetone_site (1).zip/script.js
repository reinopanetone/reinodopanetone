
const produtos = [
  { nome: 'Panetone de Chocolate', preco: 49.90, img: 'https://pixabay.com/get/gc9b3f6f71ed270f...' },
  { nome: 'Panetone de Frutas', preco: 39.90, img: 'https://pixabay.com/get/g9b3f6f71ed270f...' }
];
document.getElementById('produtos').innerHTML = produtos.map(p => `<div><h2>${p.nome}</h2><img src='${p.img}' width='200'><p>R$ ${p.preco}</p></div>`).join('');
